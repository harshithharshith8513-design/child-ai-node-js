const injectScript = () => {
  try {
    const container = document.head || document.documentElement;
    const script = document.createElement('script');
    script.textContent = `window.childguardExtensionId = "${chrome.runtime.id}";`;
    container.appendChild(script);
    script.remove();
  } catch (e) {
    console.error("ChildGuard AI Extension ID Injection failed:", e);
  }
};
injectScript();
